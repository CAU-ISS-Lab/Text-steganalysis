
#BLOCK
python main.py -test_cover data/BLOCK/movie/test_data/test_cover.txt -test_stego data/BLOCK/movie/test_data/stego_3words_bit.txt
python main.py -test_cover data/BLOCK/news/test_data/test_cover.txt -test_stego data/BLOCK/news/test_data/stego_3words_bit.txt
python main.py -test_cover data/BLOCK/twitter/test_data/test_cover.txt -test_stego data/BLOCK/twitter/test_data/stego_3words_bit.txt

#data
python main.py -test_cover data/AC/movie/test_data/test_cover.txt -test_stego data/AC/movie/test_data/stego_3words_bit.txt
python main.py -test_cover data/AC/news/test_data/test_cover.txt -test_stego data/AC/news/test_data/stego_3words_bit.txt
python main.py -test_cover data/AC/twitter/test_data/test_cover.txt -test_stego data/AC/twitter/test_data/stego_3words_bit.txt

#ADG
python main.py -test_cover data/ADG/movie/test_data/test_cover.txt -test_stego data/ADG/movie/test_data/stego_3words_bit.txt
python main.py -test_cover data/ADG/news/test_data/test_cover.txt -test_stego data/ADG/news/test_data/stego_3words_bit.txt
python main.py -test_cover data/ADG/twitter/test_data/test_cover.txt -test_stego data/ADG/twitter/test_data/stego_3words_bit.txt


#VLC
python main.py -test_cover data/VLC/movie/test_data/test_cover.txt -test_stego data/VLC/movie/test_data/stego_3words_bit.txt
python main.py -test_cover data/VLC/news/test_data/test_cover.txt -test_stego data/VLC/news/test_data/stego_3words_bit.txt
python main.py -test_cover data/VLC/twitter/test_data/test_cover.txt -test_stego data/VLC/twitter/test_data/stego_3words_bit.txt

#DISCOP
python main.py -test_cover data/DISCOP/movie/test_data/test_cover.txt -test_stego data/DISCOP/movie/test_data/stego_3words_bit.txt
python main.py -test_cover data/DISCOP/news/test_data/test_cover.txt -test_stego data/DISCOP/news/test_data/stego_3words_bit.txt
python main.py -test_cover data/DISCOP/twitter/test_data/test_cover.txt -test_stego data/DISCOP/twitter/test_data/stego_3words_bit.txt


#BLOCK
python main.py -test_cover data/BLOCK/movie/test_data/test_cover.txt -test_stego data/BLOCK/movie/test_data/stego_3words_bit.txt -tent
python main.py -test_cover data/BLOCK/news/test_data/test_cover.txt -test_stego data/BLOCK/news/test_data/stego_3words_bit.txt -tent
python main.py -test_cover data/BLOCK/twitter/test_data/test_cover.txt -test_stego data/BLOCK/twitter/test_data/stego_3words_bit.txt -tent

#data
python main.py -test_cover data/AC/movie/test_data/test_cover.txt -test_stego data/AC/movie/test_data/stego_3words_bit.txt -tent
python main.py -test_cover data/AC/news/test_data/test_cover.txt -test_stego data/AC/news/test_data/stego_3words_bit.txt -tent
python main.py -test_cover data/AC/twitter/test_data/test_cover.txt -test_stego data/AC/twitter/test_data/stego_3words_bit.txt -tent

#ADG
python main.py -test_cover data/ADG/movie/test_data/test_cover.txt -test_stego data/ADG/movie/test_data/stego_3words_bit.txt -tent
python main.py -test_cover data/ADG/news/test_data/test_cover.txt -test_stego data/ADG/news/test_data/stego_3words_bit.txt -tent
python main.py -test_cover data/ADG/twitter/test_data/test_cover.txt -test_stego data/ADG/twitter/test_data/stego_3words_bit.txt -tent


#VLC
python main.py -test_cover data/VLC/movie/test_data/test_cover.txt -test_stego data/VLC/movie/test_data/stego_3words_bit.txt -tent
python main.py -test_cover data/VLC/news/test_data/test_cover.txt -test_stego data/VLC/news/test_data/stego_3words_bit.txt -tent
python main.py -test_cover data/VLC/twitter/test_data/test_cover.txt -test_stego data/VLC/twitter/test_data/stego_3words_bit.txt -tent

#DISCOP
python main.py -test_cover data/DISCOP/movie/test_data/test_cover.txt -test_stego data/DISCOP/movie/test_data/stego_3words_bit.txt -tent
python main.py -test_cover data/DISCOP/news/test_data/test_cover.txt -test_stego data/DISCOP/news/test_data/stego_3words_bit.txt -tent
python main.py -test_cover data/DISCOP/twitter/test_data/test_cover.txt -test_stego data/DISCOP/twitter/test_data/stego_3words_bit.txt -tent


#BLOCK
python main.py -test_cover data/BLOCK/movie/test_data/test_cover.txt -test_stego data/BLOCK/movie/test_data/stego_3words_bit.txt -ag_tta
python main.py -test_cover data/BLOCK/news/test_data/test_cover.txt -test_stego data/BLOCK/news/test_data/stego_3words_bit.txt -ag_tta
python main.py -test_cover data/BLOCK/twitter/test_data/test_cover.txt -test_stego data/BLOCK/twitter/test_data/stego_3words_bit.txt -ag_tta

#data
python main.py -test_cover data/AC/movie/test_data/test_cover.txt -test_stego data/AC/movie/test_data/stego_3words_bit.txt -ag_tta
python main.py -test_cover data/AC/news/test_data/test_cover.txt -test_stego data/AC/news/test_data/stego_3words_bit.txt -ag_tta
python main.py -test_cover data/AC/twitter/test_data/test_cover.txt -test_stego data/AC/twitter/test_data/stego_3words_bit.txt -ag_tta

#ADG
python main.py -test_cover data/ADG/movie/test_data/test_cover.txt -test_stego data/ADG/movie/test_data/stego_3words_bit.txt -ag_tta
python main.py -test_cover data/ADG/news/test_data/test_cover.txt -test_stego data/ADG/news/test_data/stego_3words_bit.txt -ag_tta
python main.py -test_cover data/ADG/twitter/test_data/test_cover.txt -test_stego data/ADG/twitter/test_data/stego_3words_bit.txt -ag_tta


#VLC
python main.py -test_cover data/VLC/movie/test_data/test_cover.txt -test_stego data/VLC/movie/test_data/stego_3words_bit.txt -ag_tta
python main.py -test_cover data/VLC/news/test_data/test_cover.txt -test_stego data/VLC/news/test_data/stego_3words_bit.txt -ag_tta
python main.py -test_cover data/VLC/twitter/test_data/test_cover.txt -test_stego data/VLC/twitter/test_data/stego_3words_bit.txt -ag_tta

#DISCOP
python main.py -test_cover data/DISCOP/movie/test_data/test_cover.txt -test_stego data/DISCOP/movie/test_data/stego_3words_bit.txt -ag_tta
python main.py -test_cover data/DISCOP/news/test_data/test_cover.txt -test_stego data/DISCOP/news/test_data/stego_3words_bit.txt -ag_tta
python main.py -test_cover data/DISCOP/twitter/test_data/test_cover.txt -test_stego data/DISCOP/twitter/test_data/stego_3words_bit.txt -ag_tta

