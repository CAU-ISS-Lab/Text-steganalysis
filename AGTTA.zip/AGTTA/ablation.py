# ablation.py
import os
import torch
import torch.nn as nn
import torch.optim as optim
import pandas as pd
import argparse
from datetime import datetime
from torch.utils.data import DataLoader, Dataset
from transformers import BertTokenizer, BertForSequenceClassification, BertModel
from tqdm import tqdm
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from config import Config
from utils import StegaDataset, EntropyLoss, calculate_metrics

class UnlabeledDatasetForScores(Dataset):
    """A class specifically for loading unlabeled data when generating scores."""

    def __init__(self, file_paths, tokenizer, max_len):
        self.tokenizer, self.max_len = tokenizer, max_len
        self.lines, self.ground_truth = [], []
        with open(file_paths[0], 'r', encoding='utf-8', errors='ignore') as f:
            lines = [line.strip() for line in f.readlines()]
            self.lines.extend(lines);
            self.ground_truth.extend([0] * len(lines))
        with open(file_paths[1], 'r', encoding='utf-8', errors='ignore') as f:
            lines = [line.strip() for line in f.readlines()]
            self.lines.extend(lines);
            self.ground_truth.extend([1] * len(lines))

    def __len__(self): return len(self.lines)

    def __getitem__(self, idx):
        text = self.lines[idx]
        encoding = self.tokenizer.encode_plus(
            text, add_special_tokens=True, max_length=self.max_len, padding='max_length',
            truncation=True, return_attention_mask=True, return_tensors='pt'
        )
        return {'input_ids': encoding['input_ids'].flatten(), 'attention_mask': encoding['attention_mask'].flatten()}


def get_features_for_scores(model, data_loader, device):
    """A function specifically for generating scores and extracting features."""

    model.eval()
    features_list = []
    with torch.no_grad():
        for batch in tqdm(data_loader, desc="Extracting features for anomaly scoring"):
            outputs = model(input_ids=batch['input_ids'].to(device), attention_mask=batch['attention_mask'].to(device))
            cls_features = outputs.last_hidden_state[:, 0, :].cpu().numpy()
            features_list.append(cls_features)
    return torch.vstack([torch.from_numpy(f) for f in features_list]).numpy()


def generate_anomaly_scores(args, tokenizer, base_model):
    """Automatically generate anomaly score file if needed."""
    print("\n--- Pre-computation: Generating Anomaly Scores ---")

    # 1. Load data
    target_dataset = UnlabeledDatasetForScores([args.test_cover, args.test_stego], tokenizer, Config.max_len)
    target_loader = DataLoader(target_dataset, batch_size=Config.batch_size)

    # 2. Extract features
    features = get_features_for_scores(base_model, target_loader, Config.device)
    features_scaled = StandardScaler().fit_transform(features)

    # 3. Calculate scores (using Isolation Forest)
    print("Calculating scores using Isolation Forest...")
    iso_forest = IsolationForest(n_estimators=100, contamination='auto', random_state=42).fit(features_scaled)
    iso_scores = iso_forest.decision_function(features_scaled)
    # 4. Format conversion
    df = pd.DataFrame({
        'text': target_dataset.lines, 'ground_truth_label': target_dataset.ground_truth,
        Config.ag_tta_score_column: iso_scores
    })
    return df


# ==============================================================================
#  Evaluation and TTA Logic
# ==============================================================================
def evaluate(model, data_loader, device):
    """Evaluate the model and return predictions and true labels"""
    model.eval()
    all_preds, all_labels = [], []
    with torch.no_grad():
        for batch in tqdm(data_loader, desc="Evaluating"):
            all_labels.extend(batch['labels'].numpy())
            outputs = model(input_ids=batch['input_ids'].to(device), attention_mask=batch['attention_mask'].to(device))
            _, preds = torch.max(outputs.logits, dim=1)
            all_preds.extend(preds.cpu().numpy())
    return all_labels, all_preds


def adapt_tent(model, data_loader, device, epochs, lr):
    """Execute TTA (Tent: Entropy Minimization)"""

    model.eval()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    entropy_loss_fn = EntropyLoss()
    print("\n--- Starting TTA (Tent: Entropy Minimization) ---")
    for epoch in range(epochs):
        for batch in tqdm(data_loader, desc=f"TTA Epoch {epoch + 1}/{epochs}"):
            outputs = model(input_ids=batch['input_ids'].to(device), attention_mask=batch['attention_mask'].to(device))
            loss = entropy_loss_fn(outputs.logits)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
    return model


def adapt_ag_tta(model, data_loader, device, epochs, lr, alpha):
    """Execute Anomaly-Guided TTA"""

    model.eval()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    entropy_loss_fn = EntropyLoss()
    print("\n--- Starting Anomaly-Guided TTA (AG-TTA) ---")
    for epoch in range(epochs):
        for batch in tqdm(data_loader, desc=f"AG-TTA Epoch {epoch + 1}/{epochs}"):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            anomaly_scores = batch['anomaly_score'].to(device)

            outputs = model(input_ids=input_ids, attention_mask=attention_mask)
            logits = outputs.logits

            loss_entropy = entropy_loss_fn(logits)

            # Construct pseudo labels using Anomaly Scores

            normalized_scores = (anomaly_scores - anomaly_scores.min()) / (
                    anomaly_scores.max() - anomaly_scores.min() + 1e-8)
            stego_prob = normalized_scores
            cover_prob = 1.0 - normalized_scores
            soft_pseudo_labels = torch.stack([cover_prob, stego_prob], dim=1)

            log_probs = nn.functional.log_softmax(logits, dim=1)
            loss_pseudo = -torch.sum(soft_pseudo_labels * log_probs, dim=1).mean()

            total_loss = loss_entropy + alpha * loss_pseudo
            optimizer.zero_grad()
            total_loss.backward()
            optimizer.step()
    return model

def without_pl(model, data_loader, device, epochs, lr, alpha):
    """Execute Anomaly-Guided TTA (only pl)"""

    model.eval()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    entropy_loss_fn = EntropyLoss()
    print("\n--- Starting Anomaly-Guided TTA (AG-TTA) ---")
    for epoch in range(epochs):
        for batch in tqdm(data_loader, desc=f"AG-TTA Epoch {epoch + 1}/{epochs}"):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            anomaly_scores = batch['anomaly_score'].to(device)

            outputs = model(input_ids=input_ids, attention_mask=attention_mask)
            logits = outputs.logits

            # Construct pseudo labels using Anomaly Scores
            normalized_scores = (anomaly_scores - anomaly_scores.min()) / (
                    anomaly_scores.max() - anomaly_scores.min() + 1e-8)
            stego_prob = normalized_scores
            cover_prob = 1.0 - normalized_scores
            soft_pseudo_labels = torch.stack([cover_prob, stego_prob], dim=1)

            log_probs = nn.functional.log_softmax(logits, dim=1)
            loss_pseudo = -torch.sum(soft_pseudo_labels * log_probs, dim=1).mean()

            total_loss = loss_pseudo
            optimizer.zero_grad()
            total_loss.backward()
            optimizer.step()
    return model


def forzen_f(model, data_loader, device, epochs, lr, alpha):
    """Execute Anomaly-Guided TTA - update only the classifier."""

    model.eval()

    # Freeze all parameters of the BERT feature extractor

    for param in model.bert.parameters():
        param.requires_grad = False

    # Unfreeze parameters of the classifier part (last few layers)
        
    for param in model.classifier.parameters():
        param.requires_grad = True

    # Collect parameters to update
        
    params_to_update = [p for p in model.parameters() if p.requires_grad]

    # Create optimizer with only trainable parameters

    optimizer = optim.Adam(params_to_update, lr=lr)
    entropy_loss_fn = EntropyLoss()

    for epoch in range(epochs):
        for batch in tqdm(data_loader, desc=f"AG-TTA Epoch {epoch + 1}/{epochs}"):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            anomaly_scores = batch['anomaly_score'].to(device)

            outputs = model(input_ids=input_ids, attention_mask=attention_mask)
            logits = outputs.logits

            loss_entropy = entropy_loss_fn(logits)

            # Construct pseudo labels using Anomaly Scores
            normalized_scores = (anomaly_scores - anomaly_scores.min()) / (
                    anomaly_scores.max() - anomaly_scores.min() + 1e-8)
            stego_prob = normalized_scores
            cover_prob = 1.0 - normalized_scores
            soft_pseudo_labels = torch.stack([cover_prob, stego_prob], dim=1)

            log_probs = nn.functional.log_softmax(logits, dim=1)
            loss_pseudo = -torch.sum(soft_pseudo_labels * log_probs, dim=1).mean()

            total_loss = loss_entropy + alpha * loss_pseudo
            optimizer.zero_grad()
            total_loss.backward()
            optimizer.step()
    return model
def log_results(log_file, experiment_data):
    """Log experiment results to CSV file."""
    new_log_entry = pd.DataFrame([experiment_data])
    try:
        log_df = pd.read_csv(log_file)
        combined_df = pd.concat([log_df, new_log_entry], ignore_index=True)
    except (FileNotFoundError, pd.errors.EmptyDataError):
        combined_df = new_log_entry
    combined_df.to_csv(log_file, index=False)


def main(args, strategy):
    # --- 1. Initialization ---
    tokenizer = BertTokenizer.from_pretrained(Config.model_name)
    classification_model = BertForSequenceClassification.from_pretrained(Config.model_name, num_labels=2)
    classification_model.to(Config.device)

    # --- 2. AG-TTA preprocessing ---
    scores_df = None
    if args.ag_tta:
        if not os.path.exists(Config.ag_tta_scores_csv_path) or args.force_regen:
            print(f"Anomaly scores file not found or regeneration forced. Generating...")
            # Need a base BertModel to extract features
            base_model = BertModel.from_pretrained(Config.model_name).to(Config.device)
            scores_df = generate_anomaly_scores(args, tokenizer, base_model)
        else:
            print(f"Found existing anomaly scores file. Loading from '{Config.ag_tta_scores_csv_path}'")
            scores_df = pd.read_csv(Config.ag_tta_scores_csv_path)

    # --- 3. Load dataset ---
    print("\nLoading main dataset for evaluation/TTA...")
    test_dataset = StegaDataset(args.test_cover, args.test_stego, tokenizer, Config.max_len, scores_df,
                                Config.ag_tta_score_column)
    test_loader = DataLoader(test_dataset, batch_size=Config.batch_size, shuffle=False)

    # --- 4. Execute test ---
    if strategy == "ag_tta":
        tta_loader = DataLoader(test_dataset, batch_size=Config.batch_size, shuffle=True)
        classification_model = adapt_ag_tta(classification_model, tta_loader, Config.device, Config.tta_epochs,
                                                Config.tta_lr, Config.ag_tta_alpha)
    elif strategy == "tent":
        tta_loader = DataLoader(test_dataset, batch_size=Config.batch_size, shuffle=True)
        classification_model = adapt_tent(classification_model, tta_loader, Config.device, Config.tta_epochs,
                                              Config.tta_lr)
    elif strategy == "w_pl":
        tta_loader = DataLoader(test_dataset, batch_size=Config.batch_size, shuffle=True)
        classification_model = without_pl(classification_model, tta_loader, Config.device, Config.tta_epochs,
                                              Config.tta_lr)
    elif strategy == "frozen_f":
        tta_loader = DataLoader(test_dataset, batch_size=Config.batch_size, shuffle=True)
        classification_model = forzen_f(classification_model, tta_loader, Config.device, Config.tta_epochs,
                                              Config.tta_lr)
    elif strategy == "source_only":
        print("source_only")


    # --- 5. Evaluate and log ---
    labels, preds = evaluate(classification_model, test_loader, Config.device)
    metrics = calculate_metrics(labels, preds)

    log_data = {
        "Timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "Strategy": strategy,
        "Test_Cover": args.test_cover, "Test_Stego": args.test_stego,
        "TN": metrics["TN"], "FP": metrics["FP"], "FN": metrics["FN"], "TP": metrics["TP"],
        "Accuracy": f"{metrics['Accuracy']:.4f}", "Precision": f"{metrics['Precision']:.4f}",
        "Recall": f"{metrics['Recall']:.4f}", "F1-Score": f"{metrics['F1-Score']:.4f}"

    }

    print("\n--- Results ---")
    for key, value in log_data.items(): print(f"{key}: {value}")
    log_results(Config.result_log_path, log_data)
    print(f"\nResults have been logged to {Config.result_log_path}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Run Steganalysis Experiments")
    parser.add_argument('-test_cover', type=str, required=True, help="Path to the test cover text file.")
    parser.add_argument('-test_stego', type=str, required=True, help="Path to the test stego text file.")

    parser.add_argument('-strategy', type=str, required=True, help="Path to the test stego text file.")

    parser.add_argument('-force_regen', action='store_true', help="Force regeneration of anomaly scores for AG-TTA.")


    args = parser.parse_args()
    main(args, strategy='source_only')
    main(args, strategy='tent')
    main(args, strategy = 'w_pl')
    main(args, strategy='forzen_f')
    main(args, strategy='ag_tta')

