from transformers import BertTokenizer, BertForMaskedLM
from torch.utils.data import Dataset, DataLoader
import torch
import math
'''
class MyDataset(Dataset):
    def __init__(self, sentences, tokenizer, max_length=512):
        self.sentences = sentences
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.sentences)

    def __getitem__(self, idx):
        sentence = self.sentences[idx]
        encoding = self.tokenizer(sentence, truncation=True, max_length=self.max_length, padding='max_length')
        return {
            'input_ids': torch.tensor(encoding['input_ids'], dtype=torch.long),
            'attention_mask': torch.tensor(encoding['attention_mask'], dtype=torch.long),
            'labels': torch.tensor(encoding['input_ids'], dtype=torch.long)
        }

# load pretrained tokenizer and model
model_path = r"C:\wjx\研究生\论文\基于chatGPT的文本隐写\数据\第三次数据制作\数据\base_uncased"
tokenizer_path = r"C:\wjx\研究生\论文\基于chatGPT的文本隐写\数据\第三次数据制作\数据\base_uncased"
tokenizer = BertTokenizer.from_pretrained(tokenizer_path)
model = BertForMaskedLM.from_pretrained(model_path)
model = model.to('cuda' if torch.cuda.is_available() else 'cpu') # adjust as necessary

# load your sentences
with open("ADGstego.txt", 'r') as f:
    sentences = f.read().split('\n')

# create your Dataset and Dataloader
dataset = MyDataset(sentences, tokenizer)
dataloader = DataLoader(dataset, batch_size=32) # adjust batch size as necessary

def evaluate(model, dataloader):
    model.eval()
    total_val_loss = 0
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    with torch.no_grad():
        for step, batch in enumerate(dataloader):
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels = batch['labels'].to(device)

            outputs = model(input_ids, attention_mask=attention_mask, labels=labels)
            loss = outputs.loss
            total_val_loss += loss.item()

    loss = total_val_loss / len(dataloader)
    perplexity = math.exp(loss)
    perplexity = torch.tensor(perplexity)
    return loss, perplexity

# call the function
loss, perplexity = evaluate(model, dataloader)
print(f"Perplexity: {perplexity}")



from transformers import BertTokenizer, BertForMaskedLM
import torch

# 设置模型和词汇表文件的路径
model_path = "base_uncased"  # 替换为你的模型文件路径
tokenizer_path = "base_uncased"  # 替换为你的词汇表文件路径

# 加载预训练模型的tokenizer (词汇表)
tokenizer = BertTokenizer.from_pretrained(tokenizer_path)

# 加载预训练模型
model = BertForMaskedLM.from_pretrained(model_path)
model.eval()

def calculate_ppl(sentence):
    tokenize_input = tokenizer.tokenize(sentence)
    tensor_input = torch.tensor([tokenizer.convert_tokens_to_ids(tokenize_input)])
    loss=model(tensor_input, labels=tensor_input)[0]
    return torch.exp(loss)

# 假设你的文本文件为 sentences.txt
with open("AC_6stego.txt", "r",encoding='utf-8') as file:
    sentences = file.readlines()

ppl_values = []
for sentence in sentences:
    ppl = calculate_ppl(sentence)
    ppl_values.append(ppl)

average_ppl = sum(ppl_values) / len(ppl_values)
print(f"Average PPL: {average_ppl}")

'''
#huggingface 的计算
from evaluate import load

perplexity = load("perplexity", module_type="metric")

with open("stego_3words_bit.txt", "r",encoding='utf-8') as file:
    input_texts = file.readlines()

results = perplexity.compute(model_id='gpt2', add_start_token=False, predictions=input_texts)

print(f"Average perplexity: {results['mean_perplexity']}")
