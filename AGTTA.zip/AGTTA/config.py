# config.py
import torch
import datetime
import os


class Config:
    # --- Basic Configuration ---

    model_name = 'pretrained_BERT/uncased/'
    max_len = 128
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # --- File Directory Configuration ---
    files_dir = "files"  
    os.makedirs(files_dir, exist_ok=True)  # Ensure the directory exists

    # --- File Paths ---
    result_log_path = "results.csv"  

    # --- TTA(Tent) Configuration ---
    tta_lr = 1e-5
    tta_epochs = 1
    batch_size = 4

    # --- AG-TTA Configuration ---
    ag_tta_alpha = 0.5
    ag_tta_score_column = 'iso_forest_score'

    # Timestamped file name
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    ag_tta_scores_csv_path = os.path.join(files_dir, f"target_data_with_anomaly_scores_{timestamp}.csv")