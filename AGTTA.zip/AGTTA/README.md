# AGTTA: Anomaly-Guided Test-Time Adaptation for Linguistic Steganalysis

A framework for linguistic steganalysis using BERT and anomaly-guided test-time adaptation.

## Project Structure

```
AGTTA/
├── main.py              # Main script - runs steganalysis experiments
├── ablation.py          # Ablation study - compares different strategies
├── config.py            # Configuration parameters (model, paths, hyperparameters)
├── utils.py             # Utility functions (dataset loader, loss functions, metrics)
├── visualization.py     # Feature visualization and analysis tools
└── data/                # Dataset directory (AC, BLOCK, VLC, ADG, DISCOP)
└── pretrained_BERT/     # Pretrained BERT models
```

## Quick Start

### Install Dependencies
```bash
pip install torch transformers scikit-learn pandas numpy matplotlib tqdm
```

### Run Experiments

**Source-Only (Baseline):**
```bash
python main.py -test_cover data/AC/news/test_data/test_cover.txt \
               -test_stego data/AC/news/test_data/stego_3words_bit.txt
```

**TTALS (Entropy Minimization TTA):**
```bash
python main.py -test_cover data/AC/news/test_data/test_cover.txt \
               -test_stego data/AC/news/test_data/stego_3words_bit.txt \
               -tent
```

**AG-TTA (Recommended):**
```bash
python main.py -test_cover data/AC/news/test_data/test_cover.txt \
               -test_stego data/AC/news/test_data/stego_3words_bit.txt \
               -ag_tta
```

### Run Ablation Study
```bash
python ablation.py -test_cover data/AC/news/test_data/test_cover.txt \
                   -test_stego data/AC/news/test_data/stego_3words_bit.txt
```

### Generate Visualizations
```bash
python visualization.py
```

## License

MIT License
